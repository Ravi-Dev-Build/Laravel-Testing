<?php 
include_once 'admin/backend/config.php';
include_once 'admin/backend/controller.php';

$obj=new Controller($pdo, $BASE_URL);
// $rows=$obj->searchProduct($search);
$obj->store();
$showcat=$obj->categoryShow();
// $allPro=$obj->showProduct();
// print_r($allPro)


// $searchPro = [];
// if (isset($_POST['searchProduct'])) {
//     $searchPro = $obj->searchProduct();
// }

$allPro = [];

if (!empty($_GET['search'])) {
    $allPro = $obj->searchProduct($_GET['search']);
} else {
    $allPro = $obj->showProduct();
}


 
 
?>
<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cars</title>
	<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"crossorigin="anonymous"> -->
	<link rel="stylesheet" type="text/css" href="public/assets/css/style.css">
</head>
<body>
<header>
	<div class="header-top">
	<div class="logo"><h2>Logo</h2></div>
	<nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="#">Services</a></li>
			<li><a href="#">Gallery</a></li>
			<li><a href="#">Contact Us</a></li>
		</ul>
	</nav>
	<div class="search-bar">
		<form method="GET">
			 			<input type="text" name="search" class="search-items" placeholder="Search Producs..." required>
			 			<button type="submit" class="btn-primary-search">Search</button>
			 		</form>
	</div>
	<div class="toggle-bar">
		<div class="bar1"></div>
		<div class="bar2"></div>
		<div class="bar3"></div>
	</div> 
	</div>
</header>
<main>
	<section>
	<div class="hero-banner">
 		<img src="public/uploads/car.jpg" alt="car">
	</div>
</section>

	<section>
		<div class="book-container">
			<article>
				<h2>Book Now</h2>
			<hr>
			<div class="form-box-row">	
		
			<form method="POST" enctype="multipart/form-data">
			 <div class="form-box">
			 <input type="text" name="name" class="text-field" placeholder="name" required>
			 <input type="email" name="email" class="text-field" placeholder="email" required>
			 <input type="number" name="phone" class="text-field" placeholder="phone" required>
			 <textarea name="address" class="text-field" required></textarea>
			 <div class="dropdown-box">
            <div class="dropdown-label" onclick="toggleDropdown(event, 'carDropdownModal')">
                Select Cars ⬇
            </div>

            <div class="dropdown-content" id="carDropdownModal">

                <?php foreach ($allPro as $pro) { ?>
                    <label class="checkbox-item">
                        <input type="checkbox" name="pro_name[]" value="<?= $pro['pro_id']; ?>">
                        <?= $pro['pro_name']; ?>  
                    </label>
                <?php } ?>
            </div>
        </div>


			 <input type="submit" name="submit" class="btn btn-primary" value="Booking">
			 </div>
			 </form>
		</div>
	</article>
</div>
	 
		</section>
	 
	 

		<section>
		<div class="car-container">
			<article>
			<h2>Most Searched Car</h2>
			<hr>
			<div class="car-row">		
				
		 
<?php foreach ($allPro as $pro) {?>
<div class="car-card">
	<div class="car-img">
		<span class="car-badge">New</span>
		<img src="<?= $BASE_URL ?>admin/assets/images/<?= htmlspecialchars($pro['pro_image']) ?>">
	</div>
	<div class="car-content">
		<h2 class="car-title"><?= htmlspecialchars($pro['pro_name']) ?></h2>
		<p class="car-subtitle">SUV • Diesel • Automatic</p>
	<div class="car-features">
        <div class="feature">7 Seater</div>
        <div class="feature">4x4</div>
        <div class="feature">Mileage 14 km/l</div>
        <div class="feature">Top Speed 180 km/h</div>
      </div>

      <div class="price">₹<?= htmlspecialchars($pro['pro_price']) ?> Lakh</div>

      <div class="btn-group">
        <button class="btn details-btn" onclick="openDetails()">View Details</button>
        <button class="btn book-btn" onclick="openBooking()">Book Now</button>
      </div>
    </div>
			
		</div> 
<?php } ?>	

		
	 
			</div>
		</div>
		</article>
		</section>

 
		 
<section>
		<div class="car-container">
			<article>
			<h2>Latest Car</h2>
			<hr>
			<div class="car-row">		
				
		 
<?php foreach ($allPro as $pro) 
	

{?>


<div class="car-card">
	<div class="car-img">
		<span class="car-badge">New</span>
		<img src="<?= $BASE_URL ?>admin/assets/images/<?= htmlspecialchars($pro['pro_image']) ?>">
	</div>
	<div class="car-content">
		<h2 class="car-title"><?= htmlspecialchars($pro['pro_name']) ?></h2>
		<p class="car-subtitle">SUV • Diesel • Automatic</p>
	<div class="car-features">
        <div class="feature">7 Seater</div>
        <div class="feature">4x4</div>
        <div class="feature">Mileage 14 km/l</div>
        <div class="feature">Top Speed 180 km/h</div>
      </div>

      <div class="price">₹<?= htmlspecialchars($pro['pro_price']) ?> Lakh</div>

      <div class="btn-group">
        <button class="btn details-btn" onclick="openDetails()">View Details</button>
        <button class="btn book-btn" onclick="openBooking()">Book Now</button>
      </div>
    </div>
			
		</div> 
<?php } ?>	

		
	 
			</div>
		</div>
		</article>
		</section>

 <!-- car-details-modal -->

 <div class="modal" id="detailsModal">
 	<div class="modal-content">
 		 <h2>Car Specifications</h2>
      	<ul>
        <li>Engine: 2755 cc</li>
        <li>Power: 201 bhp</li>
        <li>Torque: 500 Nm</li>
        <li>Fuel Type: Diesel</li>
        <li>Transmission: Automatic</li>
        <li>Safety Rating: 5 Star</li>
      </ul>
      <button class="close-btn" onclick="closeDetails()">Close</button>
 	</div>
 	
 </div>

 <!-- car-booiking-modal -->
 <div class="modal" id="bookingCar">
 	<div class="modal-content">
 		<h2>Booking Car</h2>
 			<form method="POST" enctype="multipart/form-data">
     		<input type="text" name="name" class="text-field" placeholder="name" required>
			 <input type="email" name="email" class="text-field" placeholder="email" required>
			 <input type="number" name="phone" class="text-field" placeholder="phone" required>
			 <textarea name="address" class="text-field" required></textarea>
			 	 
	 			<div class="dropdown-box">
            <div class="dropdown-label"  onclick="toggleDropdown(event, 'carDropdownForm')">
                Select Cars ⬇
            </div>

            <div class="dropdown-content" id="carDropdownForm">
                <?php foreach ($allPro as $pro) { ?>
                    <label class="checkbox-item">
                        <input type="checkbox" name="pro_name[]" value="<?= $pro['pro_id']; ?>">
                        <?= $pro['pro_name']; ?>  
                    </label>
                <?php } ?>
            </div>
        </div>
    </form>

			 	 
			 <!-- </select> -->
      
      <button class="submit-btn" name="submit" onclick="submitBooking()">Confirm Booking</button>
      <button class="close-btn" onclick="closeBooking()">Cancel</button>
 	</div>
 	
 </div>

 <div class="modal" id="successModal">
 	<div class="modal-content">
 		<h2 style="color:#0f9d58;"> Booking Confirmed!</h2>
      <p style="margin:15px 0; font-size:15px; color:#555;">
        Thank you for choosing <strong>Toyota Fortuner</strong>.
        <br>Your booking request has been successfully submitted.
      </p>
      <p style="font-size:14px; color:#777;margin-bottom: 10px;">
        Our team will contact you shortly for further process.
      </p>
      <button class="submit-btn" onclick="closeSuccess()">Great!</button>
 	</div>
 </div>
 	 
		 
	 
</main>
<footer>
	<p>&copy; cars</p>
</footer>



<script type="text/javascript">
	function openDetails()
	{
		document.getElementById('detailsModal').style.display='flex';
	}
	function closeDetails()
	{
		document.getElementById('detailsModal').style.display='none';
	}
	function openBooking()
	{
		document.getElementById('bookingCar').style.display='flex';
	}
	function closeBooking()
	{
		document.getElementById('bookingCar').style.display='none';
	}
	function showSuccess()
	{
		document.getElementById('successModal').style.display='flex';
	}
	function closeSuccess()
	{
		document.getElementById('successModal').style.display='none';
	}

	// function submitBooking()
	// {
		// alert('Hello')

    //   closeBooking();
    //   showSuccess();
	// }

  closeBooking();
// function toggleDropdown() {
//     document.getElementById("carDropdown").classList.toggle("show");
// }

// document.addEventListener("click", function (e) {
//     if (!e.target.closest(".dropdown-box")) {
//         document.getElementById("carDropdown").classList.remove("show");
//     }
// });
 

 function toggleDropdown(event, dropdownId) {
    event.stopPropagation();  
    document.getElementById(dropdownId).classList.toggle("show");
}

 
document.addEventListener("click", function () {
    document.querySelectorAll(".dropdown-content").forEach(dd => {
        dd.classList.remove("show");
    });
});


</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>