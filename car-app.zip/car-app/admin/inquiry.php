<?php 
require_once 'backend/config.php';

if(!isset($_SESSION['admin']))
 {
    header('Location:index.php');
 }

include_once 'backend/controller.php';
$obj= new Controller($pdo, $BASE_URL);
$obj->productStore();
$showcat=$obj->categoryShow();
$showAll=$obj->getAllUsers();
$obj->productDelete();
 

?>

<!doctype html>
<html lang="en">
<head>
        
        <meta charset="utf-8"/>
        <title>Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <!-- select2 css -->
        <link href="assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />

        <!-- dropzone css -->
        <link href="assets/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />

        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body data-sidebar="dark">

    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

        <!-- Begin page -->
        <div id="layout-wrapper">

            
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            

                            <a href="index.html" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="assets/images/logo-light.svg" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <img src="assets/images/logo-light.png" alt="" height="19">
                                </span>
                            </a>
                            <p class="text-white"><?php echo $_SESSION['admin']['email']; ?></p>
                        </div>

                        <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                            <i class="fa fa-fw fa-bars"></i>
                        </button>        
            </header>

            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" key="t-menu">Menu</li>
                             <li>
                                <a href="dashboard.php" class="waves-effect">
                                    <i class="bx bx-home-circle"></i> 
                                    <span key="t-dashboards">Dashboard</span>
                                </a>
                               
                            </li>
                             <li>
                                <a href="inquiry.php" class="waves-effect">
                                    <i class="bx bx-home-circle"></i> 
                                    <span key="t-dashboards">Inquiry</span>
                                </a>
                               
                            </li>
                              <li>
                                <a href="category.php" class="waves-effect">
                                    <i class="bx bx-home-circle"></i> 
                                    <span key="t-dashboards">Add Category</span>
                                </a>
                               
                            </li>
                            <li>
                                <a href="add-product.php" class="waves-effect">
                                    <i class="bx bx-home-circle"></i> 
                                    <span key="t-dashboards">Add Product</span>
                                </a>
                               
                            </li>
                             <li>
                               <a href="backend/logout.php" class="waves-effect"
                                onclick="return confirm('Are you sure you want to logout?');">
                            <i class="bx bx-power-off"></i>Logout</a>
                               
                            </li>
                        </ul>
                         
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">User Details</h4>

                                    

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                         
                            


                               <div class="row">
                            <div class="col">
                                <div class="card">
                                    <div class="card-body">
                                <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                            <thead>
                                            <tr>
                                                <th>ID#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                 <th>Phone</th>
                                                <th>Address</th>
                                                <th>Total Car</th>
                                                
                                                <th>Action</th>
                                                 
                                            </tr>
                                            </thead>
                                            <?php foreach($showAll as $row) { ?>
                                            <tr>
                                                <td><?=$row['user_id'];?></td>
                                                <td><?=$row['user_name'];?></td>
                                                <td><?=$row['user_email'];?></td>
                                                <td><?=$row['user_phone'];?></td>
                                                <td><?=$row['user_address'];?></td>
                                                <td><?=$row['total_cars'];?></td>

                                                 <td class="d-flex gap-1">

                                                    <a href="show-user.php?id=<?=$row['user_id'];?>"  class="btn btn-outline-secondary btn-sm view" title="View">
                                                             <i class="fas fa-user-alt"></i>
                                                         </a>

                                                            <a href="edit.php?id=<?=$row['user_id'];?>"  class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                                             <i class="fas fa-pencil-alt"></i>
                                                         </a>
                                                             


                                                            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                                            <input type="hidden" name="delete_id"value="<?=$row['user_id'];?>">
                                                            <button type="submit" name="delete" class="btn btn-outline-danger btn-sm delete"  title="Delete">
                                                                  <i class="bx bx-trash"></i>
                                                            </button> 
                                                            </form> 
                                                        </td>

                                            </tr>
                                            <?php } ?>
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                            
                                            
                            </div>
                        </div> 


                        </div>
                        <!-- end row -->

                        

                    </div> <!-- container-fluid -->
                </div>
            </div>
        </div>

                <!-- End Page-content -->

                
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © ccc.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop 
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">
                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="layout images">
                    </div>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="light-mode-switch" checked>
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-mode-switch">
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="rtl-mode-switch">
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-4.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-rtl-mode-switch">
                        <label class="form-check-label" for="dark-rtl-mode-switch">Dark RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>

        <!-- select 2 plugin -->
        <script src="assets/libs/select2/js/select2.min.js"></script>

        <!-- dropzone plugin -->
        <script src="assets/libs/dropzone/min/dropzone.min.js"></script>

        <!-- init js -->
        <script src="assets/js/pages/ecommerce-select2.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

    </body>
</html>
