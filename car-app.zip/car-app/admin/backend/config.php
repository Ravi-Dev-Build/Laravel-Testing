<?php
session_start();
$servername='localhost';
$dbname='car_db';
$username='root';
$password='';

try
{
	   
	$pdo=new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8",$username,$password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	// echo 'connect';
}
catch(PDOException $e)
{
	echo die('Database failed');
}

$BASE_URL='http://localhost/www/car-app/';

?>
