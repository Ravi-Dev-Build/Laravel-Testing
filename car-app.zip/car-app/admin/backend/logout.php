<?php
// require_once 'config.php';
require_once 'auth.php';

$auth=new Auth($pdo, $BASE_URL);

$auth->logout();



?>