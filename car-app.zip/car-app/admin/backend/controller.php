<?php
require_once 'config.php';
class Controller
{
	private PDO $conn;
    private string $baseUrl;

    public function __construct(PDO $pdo, string $baseUrl)
    {
        $this->conn    = $pdo;
        $this->baseUrl = $baseUrl;
    }
	public function saveCategory()
	{
		if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit']))
		{
		$catname=$_POST['category'];
		$stmt=$this->conn->prepare("INSERT INTO category_tb(cat_name) VALUES(:catname)");
		$save=$stmt->execute([':catname'=>$catname]);
		if($save)
		{
		echo "<script>alert('Category Inserted!');window.location.href='{$this->baseUrl}admin/category.php';</script>";
		}
		else
		{
		echo "<script>alert('Category Not Inserted!');window.location.href='../category.php';</script>";
		}
		}
		}
		public function categoryShow()
		{
		$stmt=$this->conn->query("SELECT * FROM category_tb WHERE cat_status='Y'");
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
	public function store()
	{
		// echo 'insert';
		if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit']))
		{
			$name=trim($_POST['name']);
			$email=trim($_POST['email']);
			$phone=trim($_POST['phone']);
			$address=trim($_POST['address']);
			// $pro_name=$_POST['pro_name'];

			if (empty($_POST['pro_name']) || !is_array($_POST['pro_name'])) {
            echo "<script>alert('Please select at least one car');</script>";
            return;
        	}

        	$cars = $_POST['pro_name'];


			$stmt=$this->conn->prepare("INSERT INTO user_tb(user_name,user_email,user_phone,user_address) 
				VALUES(:name,:email,:phone,:address)");
			$save=$stmt->execute([':name'=>$name,':email'=>$email,':phone'=>$phone,':address'=>$address]);
			 
			 $userId = $this->conn->lastInsertId();

			 $stmt = $this->conn->prepare("INSERT INTO user_product_tb(user_id, pro_id)VALUES (:user_id, :pro_id)");

        	foreach ($cars as $proId) {
            $stmt->execute([
                ':user_id' => $userId,
                ':pro_id'  => $proId
            ]);
        	}

        echo "<script>
            alert('Booking Successful!');
            window.location.href='{$this->baseUrl}';
        </script>";

		}
	}

	public function productStore()
	{
		if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit']))
		{
			$proname=trim($_POST['productname']);
			$filename=$_FILES['product_img']['name'];
			$filetmpname=$_FILES['product_img']['tmp_name'];
			$category=trim($_POST['category']);
			$price=trim($_POST['price']);
			$uploadDir = __DIR__ . '/../assets/images/';
			if(!is_dir($uploadDir))
			{
				mkdir($uploadDir,0777,true);
			}
			  if (move_uploaded_file($filetmpname, $uploadDir.$filename)) {
            	// echo "<script>alert('File Uploaded!');</script>";

        		} else {
           	 	echo "<script>alert('File Uploaded Failed!');</script>";

        	}

        	$stmt=$this->conn->prepare("INSERT INTO product_tb(cat_id,pro_name,pro_image,pro_price)
        		VALUES(:category,:proname,:filename,:price)");
        	$save=$stmt->execute([':category'=>$category,':proname'=>$proname,':filename'=>$filename,':price'=>$price]);
        	if($save)
        	{
				echo "<script>alert('Inserted Product!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";

        	}
        	else 
        	{
				echo "<script>alert('Not Inserted Product!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";

        	}
			}
			}
			public function showProduct()
			{
				$stmt=$this->conn->query("SELECT pt.*, ct.cat_id,ct.cat_name FROM product_tb pt JOIN category_tb ct 
				ON pt.cat_id = ct.cat_id
				WHERE 
				pt.pro_status='Y' ORDER BY pt.pro_id DESC 
					");
				return $stmt->fetchAll(PDO::FETCH_ASSOC);	
			}


			public function productDelete()
			{
				if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete']))
				{
					$delete_id=$_POST['delete_id'];
					$stmt=$this->conn->prepare("SELECT pro_id FROM product_tb WHERE pro_id=:id and pro_status='Y'");
					$stmt->execute([':id'=>$delete_id]);

					if($stmt->rowCount()>0)
					{
						$stmt=$this->conn->prepare("UPDATE product_tb SET pro_status='D' WhERE pro_id=:delete_id");
						$stmt->execute([':delete_id'=>$delete_id]);

						echo "<script>alert('Data Deleted Successfully!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";
					}
					else 
					{
						echo "<script>alert('Product Not Found!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";
					}

				}
				
			}

			public function editProduct($id)
			{
				 $stmt = $this->conn->prepare(
            	"SELECT * FROM product_tb WHERE pro_id=:id AND pro_status='Y'");
        		$stmt->execute([':id' => $id]);
     			return $stmt->fetch(PDO::FETCH_ASSOC);

			}

			public function updateProduct()
			{
				if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update']))
				{
					$id=$_POST['id'];
					$proname=trim($_POST['productname']);
					$filename=$_FILES['product_img']['name'];
					$filetmpname=$_FILES['product_img']['tmp_name'];
					$category=trim($_POST['category']);
					$price=trim($_POST['price']);
					
					$stmt=$this->conn->prepare("SELECT * FROM product_tb WHERE pro_id=:id and pro_status='Y'");
					$stmt->execute([':id'=>$id]);

					 $oldImage = $stmt->fetchColumn();
					 $filename = $oldImage;

					$uploadDir = __DIR__ . '/../assets/images/';
					if(!is_dir($uploadDir))
					{
					mkdir($uploadDir,0777,true);
					}
			  		if (move_uploaded_file($filetmpname, $uploadDir.$filename)) {

			  			if (!empty($oldImage) && file_exists('/../assets/images/'.$oldImage)) 
			  			{
                		unlink('/../assets/images/'.$oldImage);
            			}
            			 $filename = $oldImage;
            	 		} 

					if($stmt->rowCount()>0)
					{
					$stmt=$this->conn->prepare("UPDATE product_tb set cat_id=:category,pro_name=:proname,pro_image=:filename,pro_price=:price WHERE pro_id=:id");
        			$update=$stmt->execute([':category'=>$category,':proname'=>$proname,':filename'=>$filename,':price'=>$price,':id'=>$id]);
        			if($update)
        				{
						echo "<script>alert('Product Update Successfully!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";
					}
					else 
					{
						echo "<script>alert('Product Not Update!');window.location.href='{$this->baseUrl}admin/add-product.php';</script>";
					}
				}

				}
			}
			public function searchProduct($search)
			{
   			 $stmt = $this->conn->prepare("
        	SELECT pt.*, ct.cat_name
        	FROM product_tb pt
        	JOIN category_tb ct ON pt.cat_id = ct.cat_id
        	WHERE pt.pro_status = 'Y'
        	AND (
            pt.pro_name LIKE :search
            OR pt.pro_price LIKE :search
        		)");

    		$stmt->execute([
        	':search' => '%' . $search . '%'
    		]);

    		return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}

		public function getAllUsers()
		{
    		$stmt = $this->conn->query("
        	SELECT 
            u.user_id,
            u.user_name,
            u.user_email,
              u.user_phone,
                u.user_address,
            COUNT(up.pro_id) AS total_cars
        	FROM user_tb u
        	LEFT JOIN user_product_tb up ON u.user_id = up.user_id
        	GROUP BY u.user_id
        	ORDER BY u.user_id DESC
    		");
    		return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}

		public function getUserDetails($userId)
		{
    	$stmt = $this->conn->prepare("
        	SELECT 
            u.user_name,
            u.user_email,
            u.user_phone,
            u.user_address,
            p.pro_name,
            p.pro_price
        	FROM user_tb u
        	JOIN user_product_tb up ON u.user_id = up.user_id
        	JOIN product_tb p ON up.pro_id = p.pro_id
        	WHERE u.user_id = :user_id
    		");
    		$stmt->execute([':user_id' => $userId]);
    		return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}

	
	

}

?>
