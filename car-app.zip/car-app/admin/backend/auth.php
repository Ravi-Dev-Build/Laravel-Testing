<?php
require_once 'config.php';
class Auth
{
	private PDO $conn;
    private string $baseUrl;

    public function __construct(PDO $pdo, string $baseUrl)
    {
        $this->conn    = $pdo;
        $this->baseUrl = $baseUrl;
    }

	public function login()
	{
		if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login']))
		{
			$email=trim($_POST['email']);
			$password=trim($_POST['password']);
			if (empty($email) || empty($password)) {
            echo "<script>alert('All fields required');</script>";
            return false;
        }
			$stmt=$this->conn->prepare("SELECT id,email,password FROM admin WHERE email=:email LIMIT 1");
			$stmt->execute([':email'=>$email]);
			$auth=$stmt->fetch(PDO::FETCH_ASSOC);

			if($auth===false)
			{
				echo "<script>alert('Invalid email or password!');</script>";
				return false;

			}
			if ($password !== $auth['password']) {
            echo "<script>alert('Invalid password!');</script>";
            return false;
        }
			
			session_regenerate_id(true);
			$_SESSION['admin']=[
				'id'=>$auth['id'],
				'email'=>$auth['email']
			];
			echo "<script>alert('Login Successfully!');window.location.href='{$this->baseUrl}admin/dashboard.php';</script>";
			return true;
		}
	}
	public function logout()
    {
        if (isset($_SESSION['admin'])) {
            session_unset();
            session_destroy();
        }

        header("Location: {$this->baseUrl}admin/index.php");
        exit;
    }
}
?>