Base Path:
http://localhost/www/car-app/
Admin: 
Email: admin@gmail.com
Password: admin567