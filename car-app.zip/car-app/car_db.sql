-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2025 at 01:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin@gmail.com', 'admin567', '2025-12-17 04:20:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_tb`
--

CREATE TABLE `category_tb` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_status` enum('Y','N','D') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_tb`
--

INSERT INTO `category_tb` (`cat_id`, `cat_name`, `cat_status`, `created_at`, `updated_at`) VALUES
(1, 'Hyundai Aura', 'Y', '2025-12-17 08:47:58', NULL),
(2, 'SUV', 'Y', '2025-12-19 05:04:48', NULL),
(3, 'Hatchback', 'Y', '2025-12-19 10:26:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_tb`
--

CREATE TABLE `product_tb` (
  `pro_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pro_name` varchar(255) NOT NULL,
  `pro_image` varchar(255) NOT NULL,
  `pro_price` varchar(255) NOT NULL,
  `pro_status` enum('Y','N','D') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_tb`
--

INSERT INTO `product_tb` (`pro_id`, `cat_id`, `pro_name`, `pro_image`, `pro_price`, `pro_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Hyundai Aura', '1', '8', 'Y', '2025-12-17 08:49:20', '2025-12-17 12:18:51'),
(2, 1, 'car1', '2', '8', 'D', '2025-12-18 15:56:01', '2025-12-18 16:09:13'),
(3, 2, 'Tata Sierra', 'front-left-side-47.avif', '15 - 22', 'Y', '2025-12-19 05:06:08', NULL),
(4, 2, 'Mahindra Bolero', 'front-left-side-47 (1).avif', '7.99 - 9.21', 'Y', '2025-12-19 05:09:30', NULL),
(5, 2, 'Kia Seltos', 'front-left-side-47 (2).avif', '10.89 - 18.90', 'Y', '2025-12-19 05:10:55', NULL),
(6, 3, 'Maruti Swift', '6', '5.80 - 8.90', 'Y', '2025-12-19 10:29:22', '2025-12-19 10:30:31');

-- --------------------------------------------------------

--
-- Table structure for table `user_product_tb`
--

CREATE TABLE `user_product_tb` (
  `user_pro_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_product_tb`
--

INSERT INTO `user_product_tb` (`user_pro_id`, `user_id`, `pro_id`, `created_at`) VALUES
(1, 20, 5, '2025-12-19 08:46:35'),
(2, 21, 5, '2025-12-19 08:47:38'),
(3, 21, 4, '2025-12-19 08:47:38'),
(4, 21, 3, '2025-12-19 08:47:38'),
(5, 21, 1, '2025-12-19 08:47:38'),
(6, 22, 5, '2025-12-19 09:57:55'),
(7, 22, 4, '2025-12-19 09:57:55'),
(8, 23, 4, '2025-12-19 10:30:59'),
(9, 24, 6, '2025-12-19 10:48:25'),
(10, 24, 5, '2025-12-19 10:48:25'),
(11, 24, 4, '2025-12-19 10:48:25'),
(12, 25, 1, '2025-12-19 11:55:31');

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE `user_tb` (
  `user_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_address` text NOT NULL,
  `user_status` enum('Y','N','D') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`user_id`, `cat_id`, `user_name`, `user_email`, `user_phone`, `user_address`, `user_status`, `created_at`, `updated_at`) VALUES
(1, 2, 'Ravi Kumar', 'ravi123@gmail.com', '454544545', 'Fagunipur', 'Y', '2025-12-17 05:54:55', NULL),
(2, 2, 'Ravi Kumar', 'ravi123@gmail.com', '454544545', 'Fagunipur', 'Y', '2025-12-17 06:00:19', NULL),
(3, 3, 'Jay', 'jay123@gmail.com', '8989898789', 'Fagunipur', 'Y', '2025-12-17 06:01:45', NULL),
(4, 4, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:02:47', NULL),
(5, 2, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:03:35', NULL),
(6, 2, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:03:58', NULL),
(7, 5, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:05:00', NULL),
(8, 2, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:07:25', NULL),
(9, 7, 'Ravi Kumar', 'ravi123@gmail.com', '446456', 'Fagunipur', 'Y', '2025-12-17 06:14:47', NULL),
(10, 4, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:15:32', NULL),
(11, 3, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:15:46', NULL),
(12, 4, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:18:04', NULL),
(13, 5, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:21:53', NULL),
(14, 7, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:28:27', NULL),
(15, 4, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:28:42', NULL),
(16, 10, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-17 06:29:12', NULL),
(17, 1, 'faf', 'sadfdas@sfsdf', '456464', '45', 'Y', '2025-12-18 15:22:17', NULL),
(18, 1, 'dsg', 'ravi123@gmail.com', '46456', '456546', 'Y', '2025-12-18 18:15:53', NULL),
(19, 0, 'dsafas', 'sadfdas@sfsdf', '56464', 'Fagunipur', 'Y', '2025-12-19 07:39:25', NULL),
(20, 0, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-19 08:46:35', NULL),
(21, 0, 'Ravi Kumar', 'ravi973330@gmail.com', '4645645654', 'Fagunipur', 'Y', '2025-12-19 08:47:38', NULL),
(22, 0, 'Ravi Kumar', 'rk24950305@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-19 09:57:55', NULL),
(23, 0, 'Ravi Kumar', 'ravi123@gmail.com', '5464564646', 'Fagunipur', 'Y', '2025-12-19 10:30:59', NULL),
(24, 0, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-19 10:48:25', NULL),
(25, 0, 'Ravi Kumar', 'ravi123@gmail.com', '45454', 'Fagunipur', 'Y', '2025-12-19 11:55:31', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_tb`
--
ALTER TABLE `category_tb`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD PRIMARY KEY (`pro_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `user_product_tb`
--
ALTER TABLE `user_product_tb`
  ADD PRIMARY KEY (`user_pro_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_product_tb_ibfk_1` (`pro_id`);

--
-- Indexes for table `user_tb`
--
ALTER TABLE `user_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category_tb`
--
ALTER TABLE `category_tb`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_tb`
--
ALTER TABLE `product_tb`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_product_tb`
--
ALTER TABLE `user_product_tb`
  MODIFY `user_pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_tb`
--
ALTER TABLE `user_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD CONSTRAINT `product_tb_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category_tb` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
